/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_HwAg1Meas_HwAg1Polarity_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAg1Meas_HwAg1Polarity_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAg1Meas_HwAg1Polarity_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAg1Meas_HwAg1Polarity_Val"
//
// __PST__UINT8 Rte_Read_HwAg1Meas_HwAg1Polarity_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HwAg1Meas_HwAg1_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HwAg1Meas_HwAg1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HwAg1Meas_HwAg1_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HwAg1Meas_HwAg1_Val"
//
// __PST__UINT8 Rte_Write_HwAg1Meas_HwAg1_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HwAg1Meas_HwAg1Qlfr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HwAg1Meas_HwAg1Qlfr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HwAg1Meas_HwAg1Qlfr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HwAg1Meas_HwAg1Qlfr_Val"
//
// __PST__UINT8 Rte_Write_HwAg1Meas_HwAg1Qlfr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HwAg1Meas_HwAg1RollgCntr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HwAg1Meas_HwAg1RollgCntr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HwAg1Meas_HwAg1RollgCntr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HwAg1Meas_HwAg1RollgCntr_Val"
//
// __PST__UINT8 Rte_Write_HwAg1Meas_HwAg1RollgCntr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__19 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_GetRefTmr1MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_GetRefTmr1MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_GetRefTmr1MicroSec32bit_Oper(__PST__g__34 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_GetTiSpan1MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_GetTiSpan1MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_GetTiSpan1MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_GetTiSpan1MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_GetTiSpan1MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__34 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_HwAg1Offs_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_HwAg1Offs_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_HwAg1Offs_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_HwAg1Offs_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_HwAg1Offs_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_IoHwAb_SetFctPrphlHwAg1_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_IoHwAb_SetFctPrphlHwAg1_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_IoHwAb_SetFctPrphlHwAg1_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_IoHwAb_SetFctPrphlHwAg1_Oper"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_IoHwAb_SetFctPrphlHwAg1_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAg1Meas_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAg1Meas_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAg1Meas_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAg1Meas_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_HwAg1Meas_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltFailStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltPassStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1IfFltPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltFailStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltPassStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr0PrtclFltPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltFailStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltPassStep_Val"
//
// __PST__UINT16 Rte_Prm_HwAg1Meas_HwAg1MeasHwAg1Snsr1PrtclFltPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasVrnrErrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasVrnrErrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasVrnrErrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasVrnrErrThd_Val"
//
// __PST__UINT8 Rte_Prm_HwAg1Meas_HwAg1MeasVrnrErrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasSnsr0Rev_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr0Rev_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr0Rev_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr0Rev_Ary1D"
//
// __PST__g__124 Rte_Prm_HwAg1Meas_HwAg1MeasSnsr0Rev_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasSnsr1Rev_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr1Rev_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr1Rev_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasSnsr1Rev_Ary1D"
//
// __PST__g__124 Rte_Prm_HwAg1Meas_HwAg1MeasSnsr1Rev_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAg1Meas_HwAg1MeasStep_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAg1Meas_HwAg1MeasStep_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAg1Meas_HwAg1MeasStep_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAg1Meas_HwAg1MeasStep_Ary1D"
//
// __PST__g__127 Rte_Prm_HwAg1Meas_HwAg1MeasStep_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0Raw
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0Raw"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0Raw"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0Raw"
//
// __PST__VOID Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0Raw(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0TestOk
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0TestOk"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0TestOk"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0TestOk"
//
// __PST__VOID Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer2_HwAg1Snsr0TestOk(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1Raw
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1Raw"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1Raw"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1Raw"
//
// __PST__VOID Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1Raw(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1TestOk
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1TestOk"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1TestOk"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1TestOk"
//
// __PST__VOID Rte_IrvWrite_HwAg1Meas_HwAg1MeasPer3_HwAg1Snsr1TestOk(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0Raw
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0Raw"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0Raw"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0Raw"
//
// __PST__UINT16 Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0Raw(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0TestOk
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0TestOk"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0TestOk"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0TestOk"
//
// __PST__UINT8 Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr0TestOk(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1Raw
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1Raw"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1Raw"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1Raw"
//
// __PST__UINT16 Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1Raw(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1TestOk
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1TestOk"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1TestOk"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1TestOk"
//
// __PST__UINT8 Rte_IrvRead_HwAg1Meas_HwAg1MeasPer4_HwAg1Snsr1TestOk(__PST__VOID)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function __SYNCM
//
// #pragma POLYSPACE_PURE "__SYNCM"
// #pragma POLYSPACE_CLEAN "__SYNCM"
// #pragma POLYSPACE_WORST "__SYNCM"
//
// __PST__SINT32 __SYNCM(__PST__VOID)
// {
//    ...
// }

