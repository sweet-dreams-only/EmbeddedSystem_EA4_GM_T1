typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(__PST__UINT8, __PST__UINT8);
typedef __PST__VOID __PST__g__16(void);
typedef __PST__FLOAT64 __PST__g__17(void);
typedef __PST__g__11 *__PST__g__19;
typedef volatile __PST__FLOAT64 __PST__g__20;
typedef __PST__SINT8 *__PST__g__22;
typedef volatile __PST__g__22 __PST__g__21;
typedef __PST__SINT8 __PST__g__250[1];
union __PST__g__25
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__97[3];
union __PST__g__30
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT32 __PST__g__251[1];
union __PST__g__33
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__33 __PST__g__32;
struct __PST__g__41
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 SSE110 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    const __PST__UINT32 __pst_unused_field_12 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 SSE131 : 1;
  };
typedef const struct __PST__g__41 __PST__g__40;
union __PST__g__39
  {
    __PST__g__40 BIT;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__39 __PST__g__38;
union __PST__g__43
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__24
  {
    union __PST__g__25 ESET;
    __PST__g__97 __pst_unused_field_1;
    union __PST__g__30 ECLR;
    __PST__g__97 __pst_unused_field_3;
    __PST__g__32 ESSTR0;
    __PST__g__38 ESSTR1;
    union __PST__g__43 PCMD0;
  };
typedef volatile struct __PST__g__24 __PST__g__23;
struct __PST__g__26
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__29[3];
struct __PST__g__31
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__35
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_13 : 1;
    const __PST__UINT32 __pst_unused_field_14 : 1;
    const __PST__UINT32 __pst_unused_field_15 : 1;
    const __PST__UINT32 __pst_unused_field_16 : 1;
    const __PST__UINT32 __pst_unused_field_17 : 1;
    const __PST__UINT32 __pst_unused_field_18 : 1;
    const __PST__UINT32 __pst_unused_field_19 : 1;
    const __PST__UINT32 __pst_unused_field_20 : 1;
    const __PST__UINT32 __pst_unused_field_21 : 1;
    const __PST__UINT32 __pst_unused_field_22 : 1;
    const __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    const __PST__UINT32 __pst_unused_field_25 : 1;
    const __PST__UINT32 __pst_unused_field_26 : 1;
    const __PST__UINT32 __pst_unused_field_27 : 1;
    const __PST__UINT32 __pst_unused_field_28 : 1;
    const __PST__UINT32 __pst_unused_field_29 : 1;
    const __PST__UINT32 __pst_unused_field_30 : 1;
  };
typedef const struct __PST__g__35 __PST__g__34;
struct __PST__g__44
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
union __PST__g__50
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__52
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__55
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__57
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__59
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__61
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__63
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__252[4];
union __PST__g__67
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__69
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__71
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__74
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef const union __PST__g__74 __PST__g__73;
union __PST__g__77
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__79
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const __PST__UINT16 __PST__g__84;
typedef __PST__SINT8 __PST__g__253[2];
typedef __PST__SINT8 __PST__g__254[4008];
struct __PST__g__47
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__g__97 __pst_unused_field_1;
    union __PST__g__50 MICFG0;
    union __PST__g__52 MICFG1;
    union __PST__g__55 NMICFG0;
    union __PST__g__57 NMICFG1;
    union __PST__g__59 IRCFG0;
    union __PST__g__61 IRCFG1;
    union __PST__g__63 EMK0;
    __PST__g__252 __pst_unused_field_9;
    union __PST__g__67 ESSTC0;
    union __PST__g__69 ESSTC1;
    union __PST__g__71 PCMD1;
    __PST__g__73 PS;
    __PST__g__97 __pst_unused_field_14;
    union __PST__g__77 PE0;
    union __PST__g__79 PE1;
    __PST__g__250 __pst_unused_field_17;
    __PST__g__97 __pst_unused_field_18;
    __PST__g__84 __pst_unused_field_19;
    __PST__g__253 __pst_unused_field_20;
    __PST__UINT16 __pst_unused_field_21;
    __PST__g__253 __pst_unused_field_22;
    __PST__g__252 __pst_unused_field_23;
    __PST__g__252 __pst_unused_field_24;
    __PST__g__252 __pst_unused_field_25;
    __PST__g__252 __pst_unused_field_26;
    __PST__g__254 __pst_unused_field_27;
    __PST__g__250 __pst_unused_field_28;
    __PST__g__97 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__47 __PST__g__46;
union __PST__g__48
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__49
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__51
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__53
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
struct __PST__g__56
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__58
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
struct __PST__g__60
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__62
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__64
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__65
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__66
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
struct __PST__g__68
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__70
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
  };
struct __PST__g__72
  {
    __PST__UINT32 __pst_unused_field_0 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 24;
  };
struct __PST__g__76
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__76 __PST__g__75;
struct __PST__g__78
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
struct __PST__g__80
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 18;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 2;
  };
union __PST__g__81
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__82
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__85[2];
union __PST__g__86
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__87
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__88
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__89
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
union __PST__g__90
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__91
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_19 : 1;
    __PST__UINT32 __pst_unused_field_20 : 1;
    __PST__UINT32 __pst_unused_field_21 : 1;
    __PST__UINT32 __pst_unused_field_22 : 1;
    __PST__UINT32 __pst_unused_field_23 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 1;
    __PST__UINT32 __pst_unused_field_25 : 1;
    __PST__UINT32 __pst_unused_field_26 : 1;
    __PST__UINT32 __pst_unused_field_27 : 1;
    __PST__UINT32 __pst_unused_field_28 : 1;
    __PST__UINT32 __pst_unused_field_29 : 1;
    __PST__UINT32 __pst_unused_field_30 : 1;
  };
union __PST__g__92
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__93
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 21;
  };
typedef __PST__UINT8 __PST__g__94[4008];
union __PST__g__95
  {
    __PST__g__250 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__96
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__VOID __PST__g__98(__PST__SINT32);
typedef __PST__VOID __PST__g__99(__PST__UINT32);
typedef __PST__UINT8 __PST__g__100(__PST__UINT16);
typedef __PST__VOID __PST__g__101(__PST__UINT16);
typedef __PST__VOID __PST__g__102(__PST__UINT32, __PST__UINT32);
typedef __PST__UINT32 *__PST__g__104;
typedef __PST__VOID __PST__g__103(__PST__g__104);
typedef __PST__UINT8 *__PST__g__106;
typedef __PST__VOID __PST__g__105(__PST__g__106);
union __PST__g__109
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 UINT16;
    __PST__g__253 __pst_unused_field_2;
  };
typedef __PST__SINT8 __PST__g__255[12];
typedef __PST__SINT8 __PST__g__256[56];
typedef __PST__SINT8 __PST__g__257[116];
typedef __PST__SINT8 __PST__g__258[44];
typedef __PST__SINT8 __PST__g__259[24];
struct __PST__g__108
  {
    union __PST__g__109 EIC8;
    __PST__g__253 __pst_unused_field_1;
    __PST__g__255 __pst_unused_field_2;
    __PST__g__253 __pst_unused_field_3;
    __PST__g__253 __pst_unused_field_4;
    __PST__g__253 __pst_unused_field_5;
    __PST__g__253 __pst_unused_field_6;
    __PST__g__253 __pst_unused_field_7;
    __PST__g__253 __pst_unused_field_8;
    __PST__g__253 __pst_unused_field_9;
    __PST__g__253 __pst_unused_field_10;
    __PST__g__253 __pst_unused_field_11;
    __PST__g__253 __pst_unused_field_12;
    __PST__g__253 __pst_unused_field_13;
    __PST__g__253 __pst_unused_field_14;
    __PST__g__253 __pst_unused_field_15;
    __PST__g__253 __pst_unused_field_16;
    __PST__g__253 __pst_unused_field_17;
    __PST__g__253 __pst_unused_field_18;
    __PST__g__256 __pst_unused_field_19;
    __PST__g__253 __pst_unused_field_20;
    __PST__g__253 __pst_unused_field_21;
    __PST__g__257 __pst_unused_field_22;
    __PST__g__252 __pst_unused_field_23;
    __PST__g__258 __pst_unused_field_24;
    __PST__g__252 __pst_unused_field_25;
    __PST__g__252 __pst_unused_field_26;
    __PST__g__259 __pst_unused_field_27;
    __PST__g__252 __pst_unused_field_28;
    __PST__g__252 __pst_unused_field_29;
    __PST__g__252 __pst_unused_field_30;
    __PST__g__252 __pst_unused_field_31;
    __PST__g__252 __pst_unused_field_32;
    __PST__g__252 __pst_unused_field_33;
    __PST__g__252 __pst_unused_field_34;
    __PST__g__252 __pst_unused_field_35;
    __PST__g__252 __pst_unused_field_36;
    __PST__g__252 __pst_unused_field_37;
    __PST__g__252 __pst_unused_field_38;
    __PST__g__252 __pst_unused_field_39;
    __PST__g__252 __pst_unused_field_40;
    __PST__g__252 __pst_unused_field_41;
    __PST__g__252 __pst_unused_field_42;
    __PST__g__252 __pst_unused_field_43;
  };
typedef volatile struct __PST__g__108 __PST__g__107;
struct __PST__g__110
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__112
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__113
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
typedef __PST__UINT8 __PST__g__114[12];
union __PST__g__115
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__116
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__117
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__118
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__119
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__120
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__121
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__122
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__123
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__124
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__125
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__126
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__127
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__128
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__129
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__130
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__131
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__132
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__133
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__134
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__135
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__136
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__137
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__138
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__139
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__140
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__141
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__142
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__143
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__144
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
union __PST__g__145
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
struct __PST__g__146
  {
    __PST__UINT8 __pst_unused_field_0 : 4;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 2;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 2;
    const __PST__UINT8 __pst_unused_field_7 : 1;
  };
typedef __PST__UINT8 __PST__g__147[56];
union __PST__g__149
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
typedef const union __PST__g__149 __PST__g__148;
struct __PST__g__151
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 3;
  };
typedef const struct __PST__g__151 __PST__g__150;
union __PST__g__154
  {
    __PST__g__253 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
    __PST__g__253 __pst_unused_field_2;
  };
typedef const union __PST__g__154 __PST__g__153;
struct __PST__g__156
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 8;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 4;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef3 : 3;
  };
typedef const struct __PST__g__156 __PST__g__155;
typedef __PST__UINT8 __PST__g__157[116];
typedef __PST__SINT16 __PST__g__260[2];
union __PST__g__158
  {
    __PST__g__252 __pst_unused_field_0;
    __PST__g__260 __pst_unused_field_1;
    __PST__UINT32 __pst_unused_field_2;
    __PST__g__252 __pst_unused_field_3;
  };
struct __PST__g__159
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 8;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 6;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_7 : 1;
    __PST__UINT8 __pst_unused_field_8 : 1;
    __PST__UINT8 __pst_unused_field_9 : 1;
    __PST__UINT8 __pst_unused_field_10 : 1;
    __PST__UINT8 __pst_unused_field_11 : 1;
    __PST__UINT8 __pst_unused_field_12 : 1;
    __PST__UINT8 __pst_unused_field_13 : 1;
    __PST__UINT8 __pst_unused_field_14 : 1;
    __PST__UINT8 __pst_unused_field_15 : 1;
    __PST__UINT8 __pst_unused_field_16 : 1;
    __PST__UINT8 __pst_unused_field_17 : 1;
    __PST__UINT8 __pst_unused_field_18 : 1;
    __PST__UINT8 __pst_unused_field_19 : 1;
  };
typedef __PST__UINT16 __PST__g__160[2];
typedef __PST__UINT8 __PST__g__161[4];
typedef __PST__UINT8 __PST__g__162[44];
union __PST__g__163
  {
    __PST__g__251 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__164
  {
    const __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 13;
    __PST__UINT32 __pst_unused_field_2 : 2;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 14;
  };
typedef __PST__UINT8 __PST__g__168[24];
typedef const __PST__UINT8 __PST__g__169;
typedef volatile __PST__UINT32 __PST__g__170;
typedef __PST__g__170 *__PST__g__171;
typedef __PST__VOID __PST__g__172(__PST__UINT32, __PST__g__171);
typedef __PST__g__16 *__PST__g__173;
typedef volatile __PST__UINT8 __PST__g__174;
typedef __PST__g__174 *__PST__g__175;
typedef __PST__VOID __PST__g__176(__PST__UINT8, __PST__g__175);
typedef volatile __PST__g__73 __PST__g__177;
typedef __PST__g__177 *__PST__g__178;
typedef volatile __PST__g__169 __PST__g__179;
typedef __PST__g__179 *__PST__g__180;
typedef __PST__g__23 *__PST__g__181;
typedef volatile union __PST__g__43 __PST__g__182;
typedef __PST__g__182 *__PST__g__183;
typedef __PST__g__46 *__PST__g__184;
typedef volatile union __PST__g__71 __PST__g__185;
typedef __PST__g__185 *__PST__g__186;
typedef __PST__g__172 *__PST__g__187;
typedef volatile union __PST__g__67 __PST__g__188;
typedef __PST__g__188 *__PST__g__189;
typedef volatile union __PST__g__69 __PST__g__190;
typedef __PST__g__190 *__PST__g__191;
typedef volatile union __PST__g__63 __PST__g__192;
typedef __PST__g__192 *__PST__g__193;
typedef volatile union __PST__g__50 __PST__g__194;
typedef __PST__g__194 *__PST__g__195;
typedef volatile union __PST__g__55 __PST__g__196;
typedef __PST__g__196 *__PST__g__197;
typedef volatile union __PST__g__59 __PST__g__198;
typedef __PST__g__198 *__PST__g__199;
typedef __PST__g__176 *__PST__g__200;
typedef volatile union __PST__g__25 __PST__g__201;
typedef __PST__g__201 *__PST__g__202;
typedef volatile union __PST__g__30 __PST__g__203;
typedef __PST__g__203 *__PST__g__204;
typedef const __PST__UINT32 __PST__g__205;
typedef volatile __PST__g__205 __PST__g__206;
typedef __PST__g__206 *__PST__g__207;
typedef volatile __PST__UINT16 __PST__g__208;
typedef __PST__g__208 *__PST__g__209;
typedef __PST__g__102 *__PST__g__210;
typedef __PST__g__105 *__PST__g__211;
typedef __PST__g__15 *__PST__g__212;
typedef volatile __PST__g__38 __PST__g__213;
typedef __PST__g__213 *__PST__g__214;
typedef volatile __PST__g__40 __PST__g__215;
typedef __PST__g__215 *__PST__g__216;
typedef __PST__g__98 *__PST__g__219;
typedef volatile __PST__g__32 __PST__g__220;
typedef __PST__g__220 *__PST__g__221;
typedef volatile union __PST__g__52 __PST__g__222;
typedef __PST__g__222 *__PST__g__223;
typedef __PST__g__100 *__PST__g__224;
typedef __PST__g__101 *__PST__g__225;
typedef volatile union __PST__g__79 __PST__g__226;
typedef __PST__g__226 *__PST__g__227;
typedef __PST__g__107 *__PST__g__228;
typedef volatile union __PST__g__109 __PST__g__229;
typedef __PST__g__229 *__PST__g__230;
typedef __PST__g__99 *__PST__g__231;
typedef __PST__g__103 *__PST__g__232;
typedef volatile union __PST__g__57 __PST__g__233;
typedef __PST__g__233 *__PST__g__234;
typedef volatile union __PST__g__61 __PST__g__235;
typedef __PST__g__235 *__PST__g__236;
typedef volatile union __PST__g__77 __PST__g__237;
typedef __PST__g__237 *__PST__g__238;
typedef volatile __PST__SINT32 __PST__g__239;
typedef __PST__SINT8 __PST__g__245(void);
typedef volatile __PST__SINT8 __PST__g__246;
typedef __PST__UINT8 __PST__g__247(void);
typedef __PST__SINT32 __PST__g__248(void);
typedef __PST__UINT32 __PST__g__249(void);
