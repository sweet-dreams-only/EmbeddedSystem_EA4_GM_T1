/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_GateDrv0Ctrl_DiagcStsIvtr1Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_GateDrv0Ctrl_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_GateDrv0Ctrl_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_GateDrv0Ctrl_DiagcStsIvtr1Inactv_Logl"
//
// __PST__UINT8 Rte_Read_GateDrv0Ctrl_DiagcStsIvtr1Inactv_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GateDrv0Ctrl_StrtUpSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GateDrv0Ctrl_StrtUpSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GateDrv0Ctrl_StrtUpSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GateDrv0Ctrl_StrtUpSt_Val"
//
// __PST__UINT8 Rte_Read_GateDrv0Ctrl_StrtUpSt_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_GateDrv0Ctrl_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_GateDrv0Ctrl_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_GateDrv0Ctrl_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_GateDrv0Ctrl_SysSt_Val"
//
// __PST__UINT8 Rte_Read_GateDrv0Ctrl_SysSt_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_GateDrv0Ctrl_MotDrvr0IninTestCmpl_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_GateDrv0Ctrl_MotDrvr0IninTestCmpl_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_GateDrv0Ctrl_MotDrvr0IninTestCmpl_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_GateDrv0Ctrl_MotDrvr0IninTestCmpl_Logl"
//
// __PST__UINT8 Rte_Write_GateDrv0Ctrl_MotDrvr0IninTestCmpl_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GateDrv0Ctrl_IoHwAb_GetGpioMotDrvr0Diag_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GateDrv0Ctrl_IoHwAb_GetGpioMotDrvr0Diag_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GateDrv0Ctrl_IoHwAb_GetGpioMotDrvr0Diag_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GateDrv0Ctrl_IoHwAb_GetGpioMotDrvr0Diag_Oper"
//
// __PST__UINT8 Rte_Call_GateDrv0Ctrl_IoHwAb_GetGpioMotDrvr0Diag_Oper(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GateDrv0Ctrl_IoHwAb_SetGpioGateDrv0Rst_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GateDrv0Ctrl_IoHwAb_SetGpioGateDrv0Rst_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GateDrv0Ctrl_IoHwAb_SetGpioGateDrv0Rst_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GateDrv0Ctrl_IoHwAb_SetGpioGateDrv0Rst_Oper"
//
// __PST__UINT8 Rte_Call_GateDrv0Ctrl_IoHwAb_SetGpioGateDrv0Rst_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_GateDrv0Ctrl_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_GateDrv0Ctrl_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_GateDrv0Ctrl_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_GateDrv0Ctrl_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_GateDrv0Ctrl_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050FailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050FailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050FailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050FailStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050FailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050PassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050PassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050PassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050PassStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x050PassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051FailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051FailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051FailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051FailStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051FailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051PassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051PassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051PassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051PassStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x051PassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055FailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055FailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055FailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055FailStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055FailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055PassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055PassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055PassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055PassStep_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlNtcNr0x055PassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg2WrVal_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg2WrVal_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg2WrVal_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg2WrVal_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg2WrVal_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg3WrVal_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg3WrVal_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg3WrVal_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg3WrVal_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg3WrVal_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg4WrVal_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg4WrVal_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg4WrVal_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg4WrVal_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg4WrVal_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg7WrVal_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg7WrVal_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg7WrVal_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg7WrVal_Val"
//
// __PST__UINT16 Rte_Prm_GateDrv0Ctrl_GateDrv0CtrlUnit0Cfg7WrVal_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_GateDrv0Ena
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_GateDrv0Ena"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_GateDrv0Ena"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_GateDrv0Ena"
//
// __PST__VOID Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_GateDrv0Ena(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_Ivtr0PhyFltInpActv
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_Ivtr0PhyFltInpActv"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_Ivtr0PhyFltInpActv"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_Ivtr0PhyFltInpActv"
//
// __PST__VOID Rte_IrvWrite_GateDrv0Ctrl_GateDrv0CtrlPer1_Ivtr0PhyFltInpActv(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_GateDrv0Ena
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_GateDrv0Ena"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_GateDrv0Ena"
// #pragma POLYSPACE_WORST "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_GateDrv0Ena"
//
// __PST__UINT8 Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_GateDrv0Ena(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_Ivtr0PhyFltInpActv
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_Ivtr0PhyFltInpActv"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_Ivtr0PhyFltInpActv"
// #pragma POLYSPACE_WORST "Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_Ivtr0PhyFltInpActv"
//
// __PST__UINT8 Rte_IrvRead_GateDrv0Ctrl_GateDrv0CtrlPer2_Ivtr0PhyFltInpActv(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Spi_WriteIB
//
// #pragma POLYSPACE_PURE "Spi_WriteIB"
// #pragma POLYSPACE_CLEAN "Spi_WriteIB"
// #pragma POLYSPACE_WORST "Spi_WriteIB"
//
// __PST__UINT8 Spi_WriteIB(__PST__UINT8 P_0, __PST__g__39 P_1)
// {
//    ...
// }


// Pragmas for function Spi_ReadIB
//
// #pragma POLYSPACE_PURE "Spi_ReadIB"
// #pragma POLYSPACE_CLEAN "Spi_ReadIB"
// #pragma POLYSPACE_WORST "Spi_ReadIB"
//
// __PST__UINT8 Spi_ReadIB(__PST__UINT8 P_0, __PST__g__27 P_1)
// {
//    ...
// }


// Pragmas for function Call_Spi_AsyncTransmit
//
// #pragma POLYSPACE_PURE "Call_Spi_AsyncTransmit"
// #pragma POLYSPACE_CLEAN "Call_Spi_AsyncTransmit"
// #pragma POLYSPACE_WORST "Call_Spi_AsyncTransmit"
//
// __PST__UINT8 Call_Spi_AsyncTransmit(__PST__UINT8 P_0)
// {
//    ...
// }

