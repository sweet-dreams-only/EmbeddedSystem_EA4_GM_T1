%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nexteer DataType Class Definition %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CrcHwStsRec1 is for the Synchronous CRC in EA4 programs.
% CrcHwStsRec1 structure has the following structure elements:
%              TaskId       --> 0
%              CrcHwSts     --> 0

% Change Log:
% 04Oct2015 KSmith     Initial Release

classdef CrcHwStsRec1 < bt.struct
    %CrcHwStsRec1 - Nexteer DataType definition.

    methods
        function obj = CrcHwStsRec1(~)
            obj = obj@bt.struct();
            
            obj.BaseType = 'CrcHwStsRec1';
            obj.InitString = 'struct( ''TaskId'' , 0, ''CrcHwSts'' , 0 )';
            obj.Description = '';
            obj.HeaderFile = 'Rte_Types.h';
            
            obj.Fields(1) = bt.structelement;
            obj.Fields(1).Name = 'TaskId';
            obj.Fields(1).EngDT = dt.u16;
            obj.Fields(1).EngMin = 0;
            obj.Fields(1).EngMax = 65535;
            obj.Fields(1).DocUnits = 'Cnt';
            obj.Fields(1).Description = '';
            
            obj.Fields(2) = bt.structelement;
            obj.Fields(2).Name = 'CrcHwSts';
            obj.Fields(2).EngDT = enum.CrcHwSts1;
            obj.Fields(2).EngMin = 0;
            obj.Fields(2).EngMax = 255;
            obj.Fields(2).DocUnits = 'Cnt';
            obj.Fields(2).Description = '';
            
            CreateBusObj(obj);
        end   
    end
end

function CreateBusObj(obj)

busElements = cell(1,length(obj.Fields));
for i = 1:length(obj.Fields)
    busElements{1,i} = { obj.Fields(i).Name , 1 , obj.Fields(i).EngDT.BaseType , -1 ,'real', 'Sample' , 'Fixed' , double(obj.Fields(i).EngMin) , double(obj.Fields(i).EngMax) , obj.Fields(i).DocUnits , obj.Fields(i).Description };
end

busCells = {{obj.BaseType,obj.HeaderFile,'','Auto','-1',busElements}};
Simulink.Bus.cellToObject(busCells);

end