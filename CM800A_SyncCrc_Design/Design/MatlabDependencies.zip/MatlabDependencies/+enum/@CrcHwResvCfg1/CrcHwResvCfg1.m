% CRCHWRESVCFG1
% Definition of Crc Hardware Reserve Configuration enumeration. This file is
% need for DataDict classes to work.

% Change Log:
% 08Jan2016  KSmith      Initial version


classdef CrcHwResvCfg1 < bt.uint8
    
    properties
    end
    
    methods
        function obj = CrcHwResvCfg1(~)
            obj = obj@bt.uint8(0);
            obj.BaseType = 'Enum: CrcHwResvCfg1';
            obj.Description = 'enum. class definition that points to the enumeration defined for Crc Hardware Reserve Configuration.';
        end
    end
    
end

