% CRCHWSTS1
% Definition of Crc Hardware Status. This file is
% need for DataDict classes to work.

% Change Log:
% 08Jan2016  KSmith      Initial version


classdef CrcHwSts1 < bt.uint8
    
    properties
    end
    
    methods
        function obj = CrcHwSts1(~)
            obj = obj@bt.uint8(0);
            obj.BaseType = 'Enum: CrcHwSts1';
            obj.Description = 'enum. class definition that points to the enumeration defined for Crc Hardware Status.';
        end
    end
    
end

