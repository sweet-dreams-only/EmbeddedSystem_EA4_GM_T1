%% CRC HARDWARE RESERVE MODE ENUMERATION
% Definition of enumeration for CrcHwResvMod1. This file is
% needed for Simulink to work.

% Change Log:
% 08Jan2016  KSmith      Initial version

classdef CrcHwResvMod1 < Simulink.IntEnumType
    enumeration
        CRCHWRESVMOD_RELS   (0)
        CRCHWRESVMOD_RESV   (1)
    end
    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition of CrcHwResvMod1.';
        end
        function retVal = getDefaultValue()
			retVal = CrcHwResvMod1.CRCHWRESVMOD_RELS;
        end
        function retVal = getHeaderFile()
            retVal = 'Rte_Type.h';
        end
        function retVal = addClassNameToEnumNames()
			retVal = true;
		end
    end
end