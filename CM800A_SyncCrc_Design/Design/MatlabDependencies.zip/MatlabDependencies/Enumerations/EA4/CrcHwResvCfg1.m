%% CRC HARDWARE RESERVE CONFIGURATION ENUMERATION
% Definition of enumeration for CrcHwResvCfg1. This file is
% needed for Simulink to work.

% Change Log:
% 08Jan2016  KSmith      Initial version

classdef CrcHwResvCfg1 < Simulink.IntEnumType
    enumeration
        CRCHWRESVCFG_32BITCRC32BITWIDTH (0)
        CRCHWRESVCFG_32BITCRC16BITWIDTH (1)
        CRCHWRESVCFG_32BITCRC8BITWIDTH  (2)
        CRCHWRESVCFG_16BITCRC16BITWIDTH (3)
        CRCHWRESVCFG_16BITCRC8BITWIDTH  (4)
        CRCHWRESVCFG_8BITCRC            (5)
        CRCHWRESVCFG_8BITCRCH2F         (6)
    end
    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition of CrcHwResvCfg1.';
        end
        function retVal = getDefaultValue()
			retVal = CrcHwResvCfg1.CRCHWRESVCFG_32BITCRC32BITWIDTH;
        end
        function retVal = getHeaderFile()
            retVal = 'Rte_Type.h';
        end
        function retVal = addClassNameToEnumNames()
			retVal = true;
		end
    end
end