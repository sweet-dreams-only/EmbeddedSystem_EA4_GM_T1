%% CRC HARDWARE STATUS ENUMERATION
% Definition of enumeration for CrcHwSts1. This file is
% needed for Simulink to work.

% Change Log:
% 08Jan2016  KSmith      Initial version

classdef CrcHwSts1 < Simulink.IntEnumType
    enumeration
        CRCHWSTS_NOTAVL     (0)
        CRCHWSTS_AVL        (1)
        CRCHWSTS_BUSY       (2)
        CRCHWSTS_NOTENAD    (3)
        CRCHWSTS_RESV       (4)
        CRCHWSTS_IDXINVLD   (255)
    end
    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition of CrcHwSts1.';
        end
        function retVal = getDefaultValue()
            retVal = CrcHwSts1.CRCHWSTS_IDXINVLD;
        end
        function retVal = getHeaderFile()
            retVal = 'Rte_Type.h';
        end
        function retVal = addClassNameToEnumNames()
            retVal = true;
        end
    end
end