#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__644 _main_gen_init_g644(void);

extern union __PST__g__605 _main_gen_init_g605(void);

extern union __PST__g__577 _main_gen_init_g577(void);

extern __PST__g__493 _main_gen_init_g493(void);

extern __PST__g__483 _main_gen_init_g483(void);

extern union __PST__g__233 _main_gen_init_g233(void);

extern __PST__g__227 _main_gen_init_g227(void);

extern union __PST__g__203 _main_gen_init_g203(void);

extern union __PST__g__196 _main_gen_init_g196(void);

extern union __PST__g__189 _main_gen_init_g189(void);

extern __PST__g__170 _main_gen_init_g170(void);

extern struct __PST__g__147 _main_gen_init_g147(void);

extern union __PST__g__145 _main_gen_init_g145(void);

extern struct __PST__g__161 _main_gen_init_g161(void);

extern union __PST__g__160 _main_gen_init_g160(void);

extern struct __PST__g__152 _main_gen_init_g152(void);

extern union __PST__g__151 _main_gen_init_g151(void);

extern union __PST__g__154 _main_gen_init_g154(void);

extern struct __PST__g__143 _main_gen_init_g143(void);

extern union __PST__g__142 _main_gen_init_g142(void);

extern union __PST__g__138 _main_gen_init_g138(void);

extern union __PST__g__136 _main_gen_init_g136(void);

extern union __PST__g__134 _main_gen_init_g134(void);

extern union __PST__g__130 _main_gen_init_g130(void);

extern union __PST__g__128 _main_gen_init_g128(void);

extern union __PST__g__126 _main_gen_init_g126(void);

extern union __PST__g__124 _main_gen_init_g124(void);

extern union __PST__g__119 _main_gen_init_g119(void);

extern union __PST__g__83 _main_gen_init_g83(void);

extern __PST__g__28 _main_gen_init_g28(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_CDD_DmaCfgAndUse _main_gen_init_g26(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_DmaCfgAndUse _main_gen_init_g26(void)
{
    static struct Rte_CDS_CDD_DmaCfgAndUse x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        x.Pim_DmaCfgAndUse2MilliSecAdcStrtTi = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g8();
        }
        x.Pim_MotAg0ReadPtrRst = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g8();
        }
        x.Pim_MotAg0TrsmStrt = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g8();
        }
        x.Pim_MotAg1ReadPtrRst = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g8();
        }
        x.Pim_MotAg1TrsmStrt = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g8();
        }
        x.Pim_d2MilliSecAdcActDmaTrfTi = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g8();
        }
        x.Pim_d2MilliSecAdcMaxDmaTrfTi = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}

union __PST__g__83 _main_gen_init_g83(void)
{
    static union __PST__g__83 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__119 _main_gen_init_g119(void)
{
    static union __PST__g__119 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__124 _main_gen_init_g124(void)
{
    static union __PST__g__124 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__126 _main_gen_init_g126(void)
{
    static union __PST__g__126 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__128 _main_gen_init_g128(void)
{
    static union __PST__g__128 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__130 _main_gen_init_g130(void)
{
    static union __PST__g__130 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__134 _main_gen_init_g134(void)
{
    static union __PST__g__134 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__136 _main_gen_init_g136(void)
{
    static union __PST__g__136 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__138 _main_gen_init_g138(void)
{
    static union __PST__g__138 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__143 _main_gen_init_g143(void)
{
    static struct __PST__g__143 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DTE = bitf;
    }
    return x;
}

union __PST__g__142 _main_gen_init_g142(void)
{
    static union __PST__g__142 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g143();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__154 _main_gen_init_g154(void)
{
    static union __PST__g__154 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__152 _main_gen_init_g152(void)
{
    static struct __PST__g__152 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TCC = bitf;
    }
    return x;
}

union __PST__g__151 _main_gen_init_g151(void)
{
    static union __PST__g__151 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g152();
    return x;
}

struct __PST__g__161 _main_gen_init_g161(void)
{
    static struct __PST__g__161 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQC = bitf;
    }
    return x;
}

union __PST__g__160 _main_gen_init_g160(void)
{
    static union __PST__g__160 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g161();
    return x;
}

struct __PST__g__147 _main_gen_init_g147(void)
{
    static struct __PST__g__147 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TC = bitf;
    }
    return x;
}

union __PST__g__145 _main_gen_init_g145(void)
{
    static union __PST__g__145 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g147();
    return x;
}

__PST__g__28 _main_gen_init_g28(void)
{
    __PST__g__28 x;
    /* struct/union type */
    x.CMVC = _main_gen_init_g83();
    x.DM00CM = _main_gen_init_g119();
    x.DM01CM = _main_gen_init_g119();
    x.DM02CM = _main_gen_init_g119();
    x.DM03CM = _main_gen_init_g119();
    x.DM04CM = _main_gen_init_g119();
    x.DM11CM = _main_gen_init_g119();
    x.DM12CM = _main_gen_init_g119();
    x.DM13CM = _main_gen_init_g119();
    x.DM14CM = _main_gen_init_g119();
    x.DM15CM = _main_gen_init_g119();
    x.DM16CM = _main_gen_init_g119();
    x.DM17CM = _main_gen_init_g119();
    x.DSA0 = _main_gen_init_g124();
    x.DDA0 = _main_gen_init_g126();
    x.DTC0 = _main_gen_init_g128();
    x.DTCT0 = _main_gen_init_g130();
    x.DRSA0 = _main_gen_init_g134();
    x.DRDA0 = _main_gen_init_g136();
    x.DRTC0 = _main_gen_init_g138();
    x.DCEN0 = _main_gen_init_g142();
    x.DTFR0 = _main_gen_init_g154();
    x.DSA1 = _main_gen_init_g124();
    x.DDA1 = _main_gen_init_g126();
    x.DTC1 = _main_gen_init_g128();
    x.DTCT1 = _main_gen_init_g130();
    x.DRSA1 = _main_gen_init_g134();
    x.DRDA1 = _main_gen_init_g136();
    x.DRTC1 = _main_gen_init_g138();
    x.DCEN1 = _main_gen_init_g142();
    x.DTFR1 = _main_gen_init_g154();
    x.DSA2 = _main_gen_init_g124();
    x.DDA2 = _main_gen_init_g126();
    x.DTC2 = _main_gen_init_g128();
    x.DTCT2 = _main_gen_init_g130();
    x.DRSA2 = _main_gen_init_g134();
    x.DRDA2 = _main_gen_init_g136();
    x.DRTC2 = _main_gen_init_g138();
    x.DCEN2 = _main_gen_init_g142();
    x.DTFR2 = _main_gen_init_g154();
    x.DSA3 = _main_gen_init_g124();
    x.DDA3 = _main_gen_init_g126();
    x.DTC3 = _main_gen_init_g128();
    x.DTCT3 = _main_gen_init_g130();
    x.DRSA3 = _main_gen_init_g134();
    x.DRDA3 = _main_gen_init_g136();
    x.DRTC3 = _main_gen_init_g138();
    x.DCEN3 = _main_gen_init_g142();
    x.DTFR3 = _main_gen_init_g154();
    x.DSA4 = _main_gen_init_g124();
    x.DDA4 = _main_gen_init_g126();
    x.DTC4 = _main_gen_init_g128();
    x.DTCT4 = _main_gen_init_g130();
    x.DRSA4 = _main_gen_init_g134();
    x.DRDA4 = _main_gen_init_g136();
    x.DRTC4 = _main_gen_init_g138();
    x.DCEN4 = _main_gen_init_g142();
    x.DTFR4 = _main_gen_init_g154();
    x.DSA9 = _main_gen_init_g124();
    x.DDA9 = _main_gen_init_g126();
    x.DTC9 = _main_gen_init_g128();
    x.DTCT9 = _main_gen_init_g130();
    x.DRSA9 = _main_gen_init_g134();
    x.DRDA9 = _main_gen_init_g136();
    x.DRTC9 = _main_gen_init_g138();
    x.DCEN9 = _main_gen_init_g142();
    x.DCSTC9 = _main_gen_init_g151();
    x.DTFR9 = _main_gen_init_g154();
    x.DTFRRQC9 = _main_gen_init_g160();
    x.DSA10 = _main_gen_init_g124();
    x.DDA10 = _main_gen_init_g126();
    x.DTC10 = _main_gen_init_g128();
    x.DTCT10 = _main_gen_init_g130();
    x.DRSA10 = _main_gen_init_g134();
    x.DRDA10 = _main_gen_init_g136();
    x.DRTC10 = _main_gen_init_g138();
    x.DCEN10 = _main_gen_init_g142();
    x.DTFR10 = _main_gen_init_g154();
    x.DSA11 = _main_gen_init_g124();
    x.DDA11 = _main_gen_init_g126();
    x.DTC11 = _main_gen_init_g128();
    x.DTCT11 = _main_gen_init_g130();
    x.DRSA11 = _main_gen_init_g134();
    x.DRDA11 = _main_gen_init_g136();
    x.DRTC11 = _main_gen_init_g138();
    x.DCEN11 = _main_gen_init_g142();
    x.DTFR11 = _main_gen_init_g154();
    x.DSA12 = _main_gen_init_g124();
    x.DDA12 = _main_gen_init_g126();
    x.DTC12 = _main_gen_init_g128();
    x.DTCT12 = _main_gen_init_g130();
    x.DRSA12 = _main_gen_init_g134();
    x.DRDA12 = _main_gen_init_g136();
    x.DRTC12 = _main_gen_init_g138();
    x.DCEN12 = _main_gen_init_g142();
    x.DTFR12 = _main_gen_init_g154();
    x.DSA13 = _main_gen_init_g124();
    x.DDA13 = _main_gen_init_g126();
    x.DTC13 = _main_gen_init_g128();
    x.DTCT13 = _main_gen_init_g130();
    x.DRSA13 = _main_gen_init_g134();
    x.DRDA13 = _main_gen_init_g136();
    x.DRTC13 = _main_gen_init_g138();
    x.DCEN13 = _main_gen_init_g142();
    x.DTFR13 = _main_gen_init_g154();
    x.DSA14 = _main_gen_init_g124();
    x.DDA14 = _main_gen_init_g126();
    x.DTC14 = _main_gen_init_g128();
    x.DTCT14 = _main_gen_init_g130();
    x.DRSA14 = _main_gen_init_g134();
    x.DRDA14 = _main_gen_init_g136();
    x.DRTC14 = _main_gen_init_g138();
    x.DCEN14 = _main_gen_init_g142();
    x.DCSTC14 = _main_gen_init_g151();
    x.DTFR14 = _main_gen_init_g154();
    x.DTFRRQC14 = _main_gen_init_g160();
    x.DSA15 = _main_gen_init_g124();
    x.DDA15 = _main_gen_init_g126();
    x.DTC15 = _main_gen_init_g128();
    x.DTCT15 = _main_gen_init_g130();
    x.DRSA15 = _main_gen_init_g134();
    x.DRDA15 = _main_gen_init_g136();
    x.DRTC15 = _main_gen_init_g138();
    x.DCEN15 = _main_gen_init_g142();
    x.DCST15 = _main_gen_init_g145();
    x.DCSTC15 = _main_gen_init_g151();
    x.DTFR15 = _main_gen_init_g154();
    return x;
}

union __PST__g__189 _main_gen_init_g189(void)
{
    static union __PST__g__189 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__196 _main_gen_init_g196(void)
{
    static union __PST__g__196 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__203 _main_gen_init_g203(void)
{
    static union __PST__g__203 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__170 _main_gen_init_g170(void)
{
    __PST__g__170 x;
    /* struct/union type */
    x.MCTL2 = _main_gen_init_g189();
    x.RX0W = _main_gen_init_g196();
    x.MRWP0 = _main_gen_init_g203();
    return x;
}

union __PST__g__233 _main_gen_init_g233(void)
{
    static union __PST__g__233 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__227 _main_gen_init_g227(void)
{
    __PST__g__227 x;
    /* struct/union type */
    x.DR00 = _main_gen_init_g233();
    return x;
}

__PST__g__483 _main_gen_init_g483(void)
{
    __PST__g__483 x;
    /* struct/union type */
    x.DR00 = _main_gen_init_g233();
    return x;
}

union __PST__g__577 _main_gen_init_g577(void)
{
    static union __PST__g__577 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__605 _main_gen_init_g605(void)
{
    static union __PST__g__605 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__493 _main_gen_init_g493(void)
{
    __PST__g__493 x;
    /* struct/union type */
    x.DCMP0E = _main_gen_init_g577();
    x.CMPWE = _main_gen_init_g605();
    return x;
}

struct __PST__g__644 _main_gen_init_g644(void)
{
    static struct __PST__g__644 x;
    /* struct/union type */
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_DmaCfgAndUse(void)
{
    extern __PST__g__23 Rte_Inst_CDD_DmaCfgAndUse;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_DmaCfgAndUse _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_DmaCfgAndUse)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_DmaCfgAndUse); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g26();
            }
            Rte_Inst_CDD_DmaCfgAndUse = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_DmaCfgAndUse) / 2];
        }
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__28 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g28();
    }
}

static void _main_gen_init_sym_CSIH1(void)
{
    extern __PST__g__170 CSIH1;
    
    /* initialization with random value */
    {
        CSIH1 = _main_gen_init_g170();
    }
}

static void _main_gen_init_sym_CSIH3(void)
{
    extern __PST__g__170 CSIH3;
    
    /* initialization with random value */
    {
        CSIH3 = _main_gen_init_g170();
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__227 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g227();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__483 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g483();
    }
}

static void _main_gen_init_sym_TSG31(void)
{
    extern __PST__g__493 TSG31;
    
    /* initialization with random value */
    {
        TSG31 = _main_gen_init_g493();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes(void)
{
    extern __PST__g__643 MOTCTRLMGR_MotCtrlMotAg0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < pst_random_g_8; _main_gen_tmp_16_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg0RawRes[_main_gen_tmp_16_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes(void)
{
    extern __PST__g__643 MOTCTRLMGR_MotCtrlMotAg1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < pst_random_g_8; _main_gen_tmp_17_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlMotAg1RawRes[_main_gen_tmp_17_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes(void)
{
    extern __PST__g__643 MOTCTRLMGR_MotCtrlAdc0RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < pst_random_g_8; _main_gen_tmp_18_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc0RawRes[_main_gen_tmp_18_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31DCMP0E(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlTSG31DCMP0E;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlTSG31DCMP0E = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31CMPWE(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlTSG31CMPWE;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlTSG31CMPWE = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec(void)
{
    extern struct __PST__g__644 MotCtrlMgr_TwoMilliSecToMotCtrl_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_TwoMilliSecToMotCtrl_Rec = _main_gen_init_g644();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec(void)
{
    extern struct __PST__g__644 MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec = _main_gen_init_g644();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes(void)
{
    extern __PST__g__643 MOTCTRLMGR_MotCtrlAdc1RawRes;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < pst_random_g_8; _main_gen_tmp_19_0++)
            {
                /* base type */
                MOTCTRLMGR_MotCtrlAdc1RawRes[_main_gen_tmp_19_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec(void)
{
    extern struct __PST__g__644 MotCtrlMgr_MotCtrlToTwoMilliSec_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_MotCtrlToTwoMilliSec_Rec = _main_gen_init_g644();
    }
}

static void _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec(void)
{
    extern struct __PST__g__644 MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec;
    
    /* initialization with random value */
    {
        MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec = _main_gen_init_g644();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_DmaCfgAndUse */
    _main_gen_init_sym_Rte_Inst_CDD_DmaCfgAndUse();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable CSIH1 */
    _main_gen_init_sym_CSIH1();
    
    /* init for variable CSIH3 */
    _main_gen_init_sym_CSIH3();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
    /* init for variable TSG31 */
    _main_gen_init_sym_TSG31();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc0RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc0RawRes();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31DCMP0E */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31DCMP0E();
    
    /* init for variable MOTCTRLMGR_MotCtrlTSG31CMPWE */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlTSG31CMPWE();
    
    /* init for variable MotCtrlMgr_TwoMilliSecToMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecToMotCtrl_Rec();
    
    /* init for variable MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlFromTwoMilliSec_Rec();
    
    /* init for variable MOTCTRLMGR_MotCtrlAdc1RawRes */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlAdc1RawRes();
    
    /* init for variable MotCtrlMgr_MotCtrlToTwoMilliSec_Rec */
    _main_gen_init_sym_MotCtrlMgr_MotCtrlToTwoMilliSec_Rec();
    
    /* init for variable MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec */
    _main_gen_init_sym_MotCtrlMgr_TwoMilliSecFromMotCtrl_Rec();
    
}
