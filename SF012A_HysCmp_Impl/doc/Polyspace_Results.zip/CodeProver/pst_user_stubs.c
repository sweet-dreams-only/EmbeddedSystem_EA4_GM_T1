/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_AssiCmdBas_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_AssiCmdBas_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_AssiCmdBas_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_AssiCmdBas_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_AssiCmdBas_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_AssiMechT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_AssiMechT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_AssiMechT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_AssiMechT_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_AssiMechT_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_HwTq_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_HwTq_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_HwTqOvrl_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_HwTqOvrl_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_HwTqOvrl_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_HwTqOvrl_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_HwTqOvrl_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_HysCmpCmdDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_HysCmpCmdDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_HysCmpCmdDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_HysCmpCmdDi_Logl"
//
// __PST__UINT8 Rte_Read_HysCmp_HysCmpCmdDi_Logl(__PST__g__34 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_SysFricOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_SysFricOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_SysFricOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_SysFricOffs_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_SysFricOffs_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_VehSpd_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HysCmp_WhlImbRejctnAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HysCmp_WhlImbRejctnAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HysCmp_WhlImbRejctnAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HysCmp_WhlImbRejctnAmp_Val"
//
// __PST__UINT8 Rte_Read_HysCmp_WhlImbRejctnAmp_Val(__PST__g__29 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HysCmp_HysCmpCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HysCmp_HysCmpCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HysCmp_HysCmpCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HysCmp_HysCmpCmd_Val"
//
// __PST__UINT8 Rte_Write_HysCmp_HysCmpCmd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpAssiCmdLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpAssiCmdLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpAssiCmdLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpAssiCmdLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_HysCmpAssiCmdLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFinalOutpLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFinalOutpLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFinalOutpLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFinalOutpLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_HysCmpFinalOutpLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpHwTqLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpHwTqLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpHwTqLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpHwTqLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_HysCmpHwTqLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpOutpLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpOutpLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpOutpLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpOutpLim_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_HysCmpOutpLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpRevGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpRevGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpRevGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpRevGain_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_HysCmpRevGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_SysGlbPrmSysTqRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_SysGlbPrmSysTqRat_Val"
//
// __PST__FLOAT32 Rte_Prm_HysCmp_SysGlbPrmSysTqRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpAssiInpLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpAssiInpLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpAssiInpLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpAssiInpLim_Val"
//
// __PST__UINT16 Rte_Prm_HysCmp_HysCmpAssiInpLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpEffLossY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpEffLossY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpEffLossY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpEffLossY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpEffLossY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpEffOffsY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpEffOffsY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpEffOffsY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpEffOffsY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpEffOffsY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricTScaX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricTScaX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricTScaX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricTScaX_Ary1D"
//
// __PST__g__42 Rte_Prm_HysCmp_HysCmpFricTScaX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricTScaY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricTScaY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricTScaY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricTScaY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpFricTScaY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndX_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnBlndY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOffY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOffY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOffY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOffY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOffY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOnY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOnY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOnY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOnY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpFricWhlImbRejctnOnY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpHwTqScaX_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpHwTqScaX_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpHwTqScaX_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpHwTqScaX_Ary2D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpHwTqScaX_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpHwTqScaY_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpHwTqScaY_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpHwTqScaY_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpHwTqScaY_Ary2D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpHwTqScaY_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpHysSatnY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpHysSatnY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpHysSatnY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpHysSatnY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpHysSatnY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpNegHysCmpScaX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpNegHysCmpScaX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpNegHysCmpScaX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpNegHysCmpScaX_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpNegHysCmpScaX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpNegHysCmpScaY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpNegHysCmpScaY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpNegHysCmpScaY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpNegHysCmpScaY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpNegHysCmpScaY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpNegHysCmpX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpNegHysCmpX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpNegHysCmpX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpNegHysCmpX_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpNegHysCmpX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpNegHysCmpY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpNegHysCmpY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpNegHysCmpY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpNegHysCmpY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpNegHysCmpY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpRiseX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpRiseX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpRiseX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpRiseX_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpRiseX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_HysCmpRiseY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_HysCmpRiseY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_HysCmpRiseY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_HysCmpRiseY_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_HysCmpRiseY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HysCmp_SysGlbPrmVehSpdBilnrSeln_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_HysCmp_SysGlbPrmVehSpdBilnrSeln_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HysCmp_SysGlbPrmVehSpdBilnrSeln_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_HysCmp_SysGlbPrmVehSpdBilnrSeln_Ary1D"
//
// __PST__g__39 Rte_Prm_HysCmp_SysGlbPrmVehSpdBilnrSeln_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__39 P_0, __PST__g__39 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_s16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_s16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_s16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_s16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_s16VariXu16VariY(__PST__g__42 P_0, __PST__g__39 P_1, __PST__UINT16 P_2, __PST__SINT16 P_3)
// {
//    ...
// }


// Pragmas for function BilnrIntrpnWithRound_u16_u16MplXu16MplY
//
// #pragma POLYSPACE_PURE "BilnrIntrpnWithRound_u16_u16MplXu16MplY"
// #pragma POLYSPACE_CLEAN "BilnrIntrpnWithRound_u16_u16MplXu16MplY"
// #pragma POLYSPACE_WORST "BilnrIntrpnWithRound_u16_u16MplXu16MplY"
//
// __PST__UINT16 BilnrIntrpnWithRound_u16_u16MplXu16MplY(__PST__UINT16 P_0, __PST__UINT16 P_1, __PST__g__39 P_2, __PST__UINT16 P_3, __PST__g__39 P_4, __PST__g__39 P_5, __PST__UINT16 P_6)
// {
//    ...
// }

