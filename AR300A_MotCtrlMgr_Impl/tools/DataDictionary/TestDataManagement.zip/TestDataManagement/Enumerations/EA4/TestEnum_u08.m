classdef TestEnum_u08 < Simulink.IntEnumType
    enumeration
        TestEnum_u08_Element1        (0)
        TestEnum_u08_Element2       (7)
        TestEnum_u08_Element3       (255)
    end

    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition enum.';
        end
        function retVal = getDefaultValue()
			retVal = TestEnum_u08.TestEnum_u08_Element3;
        end
        function retVal = getHeaderFile()
            retVal = '';
        end
        function retVal = addClassNameToEnumNames()
			retVal = false;
		end
    end
end