classdef TestEnum_u32 < Simulink.IntEnumType
    enumeration
        TestEnum_u32_Element1        (0)
        TestEnum_u32_Element2       (65535)
        TestEnum_u32_Element3       (2147483647)
    end

    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition enum.';
        end
        function retVal = getDefaultValue()
			retVal = TestEnum_u32.TestEnum_u32_Element3;
        end
        function retVal = getHeaderFile()
            retVal = '';
        end
        function retVal = addClassNameToEnumNames()
			retVal = false;
		end
    end
end