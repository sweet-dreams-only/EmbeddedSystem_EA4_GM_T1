classdef TestEnum_u16 < Simulink.IntEnumType
    enumeration
        TestEnum_u16_Element1        (0)
        TestEnum_u16_Element2       (256)
        TestEnum_u16_Element3       (65535)
    end

    methods (Static)
        function retVal = getDescription()
            retVal = 'Type definition enum.';
        end
        function retVal = getDefaultValue()
			retVal = TestEnum_u16.TestEnum_u16_Element3;
        end
        function retVal = getHeaderFile()
            retVal = '';
        end
        function retVal = addClassNameToEnumNames()
			retVal = false;
		end
    end
end