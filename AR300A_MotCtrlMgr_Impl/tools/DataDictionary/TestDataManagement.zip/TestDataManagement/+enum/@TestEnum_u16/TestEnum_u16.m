classdef TestEnum_u16 < bt.uint16
    
    properties
    end
    
    methods
        function obj = TestEnum_u16(~)
            obj = obj@bt.uint16(0);
            obj.BaseType = 'Enum: TestEnum_u16';
            obj.Description = 'enum. class definition.';
        end
    end
    
end

