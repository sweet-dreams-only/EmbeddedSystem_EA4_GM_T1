classdef TestEnum_u08 < bt.uint8
    
    properties
    end
    
    methods
        function obj = TestEnum_u08(~)
            obj = obj@bt.uint8(0);
            obj.BaseType = 'Enum: TestEnum_u08';
            obj.Description = 'enum. class definition.';
        end
    end
    
end

