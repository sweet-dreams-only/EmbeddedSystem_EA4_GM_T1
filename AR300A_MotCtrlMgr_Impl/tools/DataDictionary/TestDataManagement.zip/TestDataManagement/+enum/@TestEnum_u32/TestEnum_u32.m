classdef TestEnum_u32 < bt.uint32
    
    properties
    end
    
    methods
        function obj = TestEnum_u32(~)
            obj = obj@bt.uint32(0);
            obj.BaseType = 'Enum: TestEnum_u32';
            obj.Description = 'enum. class definition.';
        end
    end
    
end

